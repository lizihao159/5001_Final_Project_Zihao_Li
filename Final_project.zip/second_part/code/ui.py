import pygame
import pygame

"""
Module defining the UI (User Interface) class for displaying health and coin information in a Pygame-based game.

Classes:
    - UI: Represents the game's user interface for health and coin display.

Methods:
    - UI.__init__(self, surface): Initializes the UI with a display surface.
        - surface (pygame.Surface): The surface where the UI elements will be drawn.

    - UI.show_health(self, current, full): Displays the player's health on the UI.
        - current (int): The current health value of the player.
        - full (int): The maximum health value of the player.
        - Draws a health bar representing the player's current health on the display surface.

    - UI.show_coins(self, amount): Displays the number of coins collected on the UI.
        - amount (int): The total number of coins collected by the player.
        - Draws a coin icon and the coin count on the display surface.

Attributes:
    - self.display_surface: The surface where UI elements are drawn.
    - self.health_bar: Image representing the health bar displayed on the UI.
    - self.health_bar_topleft: The starting position of the health bar on the display surface.
    - self.bar_max_width: The maximum width of the health bar.
    - self.bar_health: The height of the health bar.
    - self.coin: Image representing the coin icon displayed on the UI.
    - self.coin_rect: Rectangular area for positioning the coin icon on the display surface.
    - self.font: Font used for displaying the coin count text.

Usage:
    - Create an instance of the UI class by passing the game display surface as an argument.
    - Call the methods `show_health` and `show_coins` to display player health and coin count respectively on the UI.
    - Customize the attributes and methods as needed for different UI elements or designs in the game.
"""


class UI:
    def __init__(self, surface):
        
        self.display_surface = surface
        
        # health
        self.health_bar = pygame.image.load('../graphics/ui/health_bar.png').convert_alpha()
        self.health_bar_topleft = (54,39) # the location where the health bar is strat to be drawn
        self.bar_max_width = 152 # the horizontal pxiel length of the health bar
        self.bar_health = 4 # the vertical pixel length of the health bar
        
        # coins
        self.coin = pygame.image.load('../graphics/ui/coin.png').convert_alpha()
        self.coin_rect = self.coin.get_rect(topleft = (50,61))
        self.font = pygame.font.Font('../graphics/ui/font.ttf', 30)

    def show_health(self,current,full):
        # the health bar is always 152 pixels long, but the health variable is 100.
        # we have to get ratio of the current health to the full health
        # so that we can use the formular (ratio * 152) to get the current health bar length
        self.display_surface.blit(self.health_bar, (20,10))
        current_health_ratio = current / full
        cureent_bar_width = self.bar_max_width * current_health_ratio
        health_bar_rect = pygame.Rect((self.health_bar_topleft),(cureent_bar_width,self.bar_health))
        pygame.draw.rect(self.display_surface,'red',health_bar_rect)
    
    def show_coins(self,amount):
        self.display_surface.blit(self.coin,self.coin_rect)
        coin_amount_surf = self.font.render(str(amount),False,'white')
        coin_amount_rect = coin_amount_surf.get_rect(midleft = (self.coin_rect.right + 4,self.coin_rect.centery))
        self.display_surface.blit(coin_amount_surf,coin_amount_rect)
        
    