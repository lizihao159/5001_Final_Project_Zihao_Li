import pygame
from support import import_folder

"""
Module defining the Player class representing the player character in a Pygame-based game.

Attributes:
    - pygame: Pygame library for game development.
    - support: Functions to support game functionalities.

Classes:
    - Player: Represents the player character in the game.

Methods:
    - Player.__init__(self, pos, surface, change_health): Initializes the player instance with initial attributes.
    - Player.import_character_assets(self): Imports character animation images for different actions.
    - Player.animate(self): Animates the player based on the current status and direction.
    - Player.get_input(self): Retrieves player input for movement and jumping.
    - Player.get_status(self): Determines the current status of the player for animation purposes.
    - Player.apply_gravity(self): Applies gravity to the player for falling.
    - Player.jump(self): Makes the player jump when the space bar is pressed.
    - Player.get_damage(self): Reduces player health when damaged and sets an invincibility period.
    - Player.invincible_timer(self): Manages the duration of the player's invincibility period.
    - Player.update(self): Updates player movements, animation, and invincibility status.

Usage:
    To use this module, create an instance of the Player class and call the `update()` method to manage the player's actions and animations in a Pygame-based game.
"""


class Player(pygame.sprite.Sprite):
    def __init__(self,pos,surface, change_health):
        # initialize the sprite class
        super().__init__()
        # set the image and rect attributes of the palyer
        self.import_character_assets()
        self.frame_index = 0 # pick the image from the list
        self.animation_speed = 0.15 # update the image every 0.15 second
        self.image = self.animations['idle'][self.frame_index]   
        self.rect = self.image.get_rect(topleft = pos)
        
        # the movement of the player
        self.direction = pygame.math.Vector2(0,0)
        self.speed = 8
        self.gravity = 0.8
        self.jump_speed = -16
        
        # create a collision rect for the player by ignoring the width of the sword to make the collision more accurate
        self.collision_rect = pygame.Rect(self.rect.topleft, (40,self.rect.height))
        
        # status of the player
        self.status = 'idle'
        self.facing_right = True # used to flip the image when the player is moving left
        # status used to check the palyer in the right position after 
        # collision with wall or floor
        self.on_ground = False
        self.on_ceiling = False
        self.on_left = False
        self.on_right = False
        
        # health change
        self.change_health = change_health
        self.invincible = False
        self.invincible_duration = 700
        self.hurt_time = 0
        
        
    # create a function to import the images
    def import_character_assets(self):
        character_path = '../graphics/character/'
        # create a list to store the images of animation
        self.animations = {'idle':[],'run':[],'jump':[],'fall':[]}
        # create a loop to get the images of animation and character
        for animation in self.animations.keys():
            full_path = character_path + animation
            # target the folder of the animation
            self.animations[animation] = import_folder(full_path)
        
    # create a function to animate the character
    def animate(self):
        animation = self.animations[self.status]
        
        # create a loop to get the frame index
        self.frame_index += self.animation_speed
        if self.frame_index >= len(animation):
            self.frame_index = 0
        image = animation[int(self.frame_index)]
        if self.facing_right:
            self.image = image
            self.rect.bottomleft = self.collision_rect.bottomleft
        else:
            flipped_image = pygame.transform.flip(image,True,False)
            self.image = flipped_image
            self.rect.bottomright = self.collision_rect.bottomright

        self.rect = self.image.get_rect(midbottom = self.rect.midbottom)
      
        
    # create a function to get the input of the player to move
    def get_input(self):
        keys = pygame.key.get_pressed()
        
        if keys[pygame.K_RIGHT]:
            self.direction.x = 1
            self.facing_right = True
                        
        elif keys[pygame.K_LEFT]:
            self.direction.x = -1
            self.facing_right = False
                        
        else:
            self.direction.x = 0
            
        # this will only allow the player to jump onece when the player is on the ground
        if keys[pygame.K_SPACE] and self.on_ground is True:
            self.jump()
    # create a function to check the status of the player to ensure play the right animation
    def get_status(self):
        if self.direction.y < 0:
            self.status = 'jump'
        elif self.direction.y > 1:
            self.status = 'fall'
        else:
            if self.direction.x != 0:
                self.status = 'run'
            else:
                self.status = 'idle'
    # create a function to add gravity to the player so that the player can fall
    def apply_gravity(self):
        self.direction.y += self.gravity
        self.collision_rect.y += self.direction.y
    # create a function to make the player jump when the space bar is pressed
    def jump(self):
        self.direction.y = self.jump_speed
        
    def get_damage(self):
        if self.invincible is False:
            self.change_health(-20)
            self.invincible = True
            self.hurt_time = pygame.time.get_ticks()
            
            
    def invincible_timer(self):
        if self.invincible:
            current_time = pygame.time.get_ticks()
            if current_time - self.hurt_time >= self.invincible_duration:
                self.invincible = False
        
        
        
    def update(self):
        # call the get_input function so that the update function can use it
        self.get_input()
        self.get_status()
        self.animate()
        self.invincible_timer()

    
        