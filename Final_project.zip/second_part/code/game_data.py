level_0 = {
    'terrain': '../levels/0/level_0_tile_layer.csv',
    'coins': '../levels/0/level_0_coins.csv',
    'enemies': '../levels/0/level_0_enemies.csv',
    'player': '../levels/0/level_0_player.csv',
    'constraints': '../levels/0/level_0_constraints.csv',
    'node_pos': (110,400),
    'node_graphics': '../graphics/overworld/0',
    'unlock':1
    }
level_1 = {
    'terrain': '../levels/1/level_1_tile_layer.csv',
    'coins': '../levels/1/level_1_coins.csv',
    'enemies': '../levels/1/level_1_enemies.csv',
    'player': '../levels/1/level_1_player.csv',
    'constraints': '../levels/1/level_1_constraints.csv',
    'node_pos': (300,220),
    'node_graphics': '../graphics/overworld/1',
    'unlock':2
    }
level_2 = {    
    'terrain': '../levels/2/level_2_tile_layer.csv',
    'coins': '../levels/2/level_2_coins.csv',
    'enemies': '../levels/2/level_2_enemies.csv',
    'player': '../levels/2/level_2_player.csv',
    'constraints': '../levels/2/level_2_constraints.csv',
    'node_pos': (480,610),
    'node_graphics': '../graphics/overworld/2',
    'unlock':3
    }
level_3 = {    
    'terrain': '../levels/3/level_3_tile_layer.csv',
    'coins': '../levels/3/level_3_coins.csv',
    'enemies': '../levels/3/level_3_enemies.csv',
    'player': '../levels/3/level_3_player.csv',
    'constraints': '../levels/3/level_3_constraints.csv',
    'node_pos': (610,350),
    'node_graphics': '../graphics/overworld/3',
    'unlock':4
    }
level_4 = {
    'terrain': '../levels/4/level_4_tile_layer.csv',
    'coins': '../levels/4/level_4_coins.csv',
    'enemies': '../levels/4/level_4_enemies.csv',
    'player': '../levels/4/level_4_player.csv',
    'constraints': '../levels/4/level_4_constraints.csv',
    'node_pos': (880,210),
    'node_graphics': '../graphics/overworld/4',
    'unlock':5
    }
level_5 = {    
    'terrain': '../levels/5/level_5_tile_layer.csv',
    'coins': '../levels/5/level_5_coins.csv',
    'enemies': '../levels/5/level_5_enemies.csv',
    'player': '../levels/5/level_5_player.csv',
    'constraints': '../levels/5/level_5_constraints.csv',
    'node_pos': (1050,400),
    'node_graphics': '../graphics/overworld/5',
    'unlock':5
    }
levels = {
    0: level_0,
    1: level_1,
    2: level_2,
    3: level_3,
    4: level_4,
    5: level_5
    }
