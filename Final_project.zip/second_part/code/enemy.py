import pygame
from tiles import AnimatedTile
from random import randint

"""
Module to handle Enemy entities in a game using Pygame.

This module defines the `Enemy` class, a type of `AnimatedTile` representing an enemy entity.
Enemies move horizontally within the game screen and can reverse direction upon hitting constraints.

Attributes:
    Inherits from:
        AnimatedTile: A class handling animated tiles within the game.
    Inherits:
        - size (int): The size of the enemy.
        - x (int): X-coordinate of the enemy's initial position.
        - y (int): Y-coordinate of the enemy's initial position.
        - rect (pygame.Rect): Rectangular area representing the enemy's position and size.
        - image (pygame.Surface): The image/sprite representing the enemy.

Methods:
    - __init__(self, size, x, y): Initializes an Enemy instance with a given size and initial position.
    - move(self): Moves the enemy horizontally based on its speed attribute.
    - reverse_image(self): Reverses the enemy's image based on its movement direction.
    - reverse(self): Reverses the enemy's movement direction.
    - update(self, shift): Updates the enemy's position, animation, and movement.

Usage:
    To use this module, import it and create instances of the Enemy class as needed for the game.
"""

class Enemy(AnimatedTile):
    def __init__(self, size, x, y):
        super().__init__(size,x,y,'../graphics/enemy/run')
        self.rect.y += size - self.image.get_size()[1]
        self.speed = randint(1,4)
    
    def move(self):
        self.rect.x += self.speed
    
    def reverse_image(self):
        if self.speed > 0:
            self.image = pygame.transform.flip(self.image,True,False)
            
    def reverse(self):
        # make the enemy reverse direction when it hits a constraint
        self.speed *= -1        
        
    def update(self, shift):
        self.rect.x += shift
        self.animate()
        self.move()
        self.reverse_image()
