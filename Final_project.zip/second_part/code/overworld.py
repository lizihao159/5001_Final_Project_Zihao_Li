import pygame
from game_data import levels
from support import import_folder

"""
Module defining the Overworld class for managing the overworld navigation in a Pygame-based game.

Attributes:
    - pygame: Pygame library for game development.
    - game_data: Data containing level information.
    - support: Functions to support game functionalities.
    - Node: Class representing nodes in the overworld.
    - Icon: Class representing the player icon in the overworld.

Classes:
    - Node: Represents individual nodes in the overworld.
    - Icon: Represents the player icon in the overworld.
    - Overworld: Manages the navigation and display of nodes in the overworld.

Methods:
    - Node.__init__(self, pos, status, icon_speed, path): Initializes a node instance with its properties.
    - Node.animate(self): Animates the node's frames if available.
    - Node.update(self): Updates the node's status and appearance based on availability.
    - Icon.__init__(self, pos): Initializes the icon instance with a position.
    - Icon.update(self): Updates the icon's position based on node movement.
    - Overworld.__init__(self, start_level, max_level, surface, create_level): Initializes the overworld with nodes, icons, and setup data.
    - Overworld.setup_nodes(self): Sets up node sprites based on the game's level data.
    - Overworld.draw_paths(self): Draws paths between nodes on the overworld.
    - Overworld.setup_icon(self): Sets up the player icon for navigation.
    - Overworld.input(self): Gets player input to control icon movement and level selection.
    - Overworld.get_movement_data(self, target): Retrieves movement data for the icon's movement.
    - Overworld.update_icon_pos(self): Updates the icon's position during movement between nodes.
    - Overworld.run(self): Runs the overworld, handling input, updating positions, and drawing elements.

Usage:
    To use this module, create an instance of the Overworld class and call the `run()` method to manage the overworld navigation in a Pygame-based game.
"""


class Node(pygame.sprite.Sprite):
    def __init__(self, pos,status,icon_speed,path):
        super().__init__()
        # setup the node
        self.frames = import_folder(path)
        self.frame_index = 0
        self.image = self.frames[self.frame_index]
        
        if status == 'available':
            self.status = 'available'
        else:
            self.status = 'locked' 
        self.rect = self.image.get_rect(center = pos)
        self.detection_zone = pygame.Rect(self.rect.centerx-(icon_speed/2),self.rect.centery-(icon_speed/2),icon_speed,icon_speed)


    def animate(self):
        self.frame_index += 0.15
        if self.frame_index >= len(self.frames):
            self.frame_index = 0
        self.image = self.frames[int(self.frame_index)]
        
    def update(self):
        if self.status == 'available':
            self.animate()
        else:
            tint_surf = self.image.copy()
            tint_surf.fill('grey',None,pygame.BLEND_RGBA_MULT)
            self.image.blit(tint_surf,(0,0))
        
class Icon(pygame.sprite.Sprite):
    def __init__(self, pos):
        super().__init__()
        # setup the icon
        self.pos = pos
        
        # load the player icon image
        self.image = pygame.image.load('../graphics/character/hat.png')
        self.rect = self.image.get_rect(center = pos)
        
    def update(self):
        # this function will update the position of the icon to make the number be the same as the node
        self.rect.center = self.pos
               
class Overworld:
    def __init__(self, start_level, max_level, surface,create_level):
        
        # setup the overworld
        self.display_surface = surface
        self.max_level = max_level
        self.current_level = start_level
        self.create_level = create_level
        # the moving variables
        self.moving = False
        self.move_direction = pygame.math.Vector2(0,0)
        self.speed = 8
        # sprite nodes
        self.setup_nodes()
        self.setup_icon()
        
    def setup_nodes(self):
        self.nodes = pygame.sprite.Group()

        for index, node_data in enumerate(levels.values()):
            if index <= self.max_level:
                node_sprite = Node(node_data['node_pos'],'available',self.speed,node_data['node_graphics'])
            else:
                node_sprite = Node(node_data['node_pos'],'locked',self.speed,node_data['node_graphics'])
            self.nodes.add(node_sprite)

    def draw_paths(self):
        ''' get ponits of the nodes '''
        if self.max_level > 0:
            points = [node['node_pos'] for index, node in enumerate(levels.values()) if index <= self.max_level]
            pygame.draw.lines(self.display_surface, 'sky blue', False, points, 6)
    
    def setup_icon(self):
        self.icon = pygame.sprite.GroupSingle()
        icon_sprite = Icon(self.nodes.sprites()[self.current_level].rect.center)
        self.icon.add(icon_sprite)
    
    # create a function to get input from the player to control the icon in the overworld
    def input(self):
        keys = pygame.key.get_pressed()
        
        if not self.moving:
            if keys[pygame.K_RIGHT] and self.current_level < self.max_level:
                self.move_direction = self.get_movement_data('next')
                self.current_level += 1
                self.moving = True
            elif keys[pygame.K_LEFT] and self.current_level > 0:
                self.move_direction = self.get_movement_data('previous')
                self.current_level -= 1
                self.moving = True
            elif keys[pygame.K_SPACE]:
                self.create_level(self.current_level)
    # creatte a function to get the movement data
    def get_movement_data(self,target):
        # this function will return the direction and the distance to move by recording the satrt and end positions
        # return end position - start position
        # example (300,220)-(110,400) = (190,-180)
        start = pygame.math.Vector2(self.nodes.sprites()[self.current_level].rect.center)
        
        # add a variable to check if the player wants to move to the next level or the previous level
        if target == 'next':
            end = pygame.math.Vector2(self.nodes.sprites()[self.current_level + 1].rect.center)
        else:
            end = pygame.math.Vector2(self.nodes.sprites()[self.current_level - 1].rect.center)
        
        return(end - start).normalize()
    
    # create a function to update the game
    def update_icon_pos(self):
        if self.moving and self.move_direction:
            self.icon.sprite.pos += self.move_direction * self.speed
            target_node = self.nodes.sprites()[self.current_level]
            if target_node.detection_zone.collidepoint(self.icon.sprite.pos):
                self.moving = False
                self.move_direction = pygame.math.Vector2(0,0)
                    
    def run(self):
        self.input()
        self.update_icon_pos()
        self.icon.update()
        self.nodes.update()
        
        self.draw_paths()
        self.nodes.draw(self.display_surface)
        self.icon.draw(self.display_surface)
        
        
        