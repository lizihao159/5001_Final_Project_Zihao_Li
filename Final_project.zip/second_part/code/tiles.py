import pygame
from support import import_folder

"""
Module defining classes for tiles and game elements in a Pygame-based game.

Classes:
    - Tile(pygame.sprite.Sprite): Represents a generic tile sprite.
        - Methods:
            - __init__(self, size, x, y): Initializes the Tile sprite with a size and position.
            - update(self, shift): Updates the tile's position based on the shift value.

    - StaticTile(Tile): Represents a static tile sprite with a fixed surface image.
        - Methods:
            - __init__(self, size, x, y, surface): Initializes the StaticTile with a surface image.
            - update(self, shift): Updates the static tile's position based on the shift value.

    - AnimatedTile(Tile): Represents an animated tile sprite cycling through a series of frames.
        - Methods:
            - __init__(self, size, x, y, path): Initializes the AnimatedTile with animation frames from a folder path.
            - animate(self): Animates the tile by cycling through the frames.
            - update(self, shift): Updates the animated tile's position and animation.

    - Coin(AnimatedTile): Represents a coin as a specialized AnimatedTile with a specific value.
        - Methods:
            - __init__(self, size, x, y, path, value): Initializes the Coin with a specific value and position.
            - update(self, shift): Updates the coin's position and animation.

Usage:
    - Instantiate the Tile, StaticTile, AnimatedTile, or Coin classes as needed in the game.
    - Modify or use their methods to handle tile movement, animation, or specialized functionalities such as coin values.
"""


class Tile(pygame.sprite.Sprite):
    def __init__(self, size, x, y):
        super().__init__()
        self.image = pygame.Surface((size, size))
        self.rect = self.image.get_rect(topleft = (x, y))
        
    def update(self, shift):
        self.rect.x += shift
        
class StaticTile(Tile):
    
    def __init__(self, size, x, y, surface):
        super().__init__(size,x,y)
        self.image = surface
        self.rect = self.image.get_rect(topleft = (x, y))
        
    def update(self, shift):
        self.rect.x += shift
        
class AnimatedTile(Tile):
    def __init__(self, size, x, y, path):
        super().__init__(size,x,y)
        self.frames = import_folder(path)
        self.frame_index = 0
        self.image = self.frames[self.frame_index]
        
        
    def animate(self):
        self.frame_index += 0.15
        if self.frame_index >= len(self.frames):
            self.frame_index = 0
        self.image = self.frames[int(self.frame_index)]
        
    def update(self, shift):
        self.rect.x += shift
        self.animate()
                
class Coin(AnimatedTile):
    def __init__(self, size, x, y, path, value):
        super().__init__(size,x,y,path)
        center_x = x + int(size/2)
        center_y = y + int(size/2)
        self.rect = self.image.get_rect(center = (center_x, center_y))
        
        self.value = value
        
