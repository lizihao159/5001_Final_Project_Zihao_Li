import pygame, sys
from settings import *
from level import Level
from overworld import Overworld
from ui import UI

"""
Module defining the Game class for managing the game loop and overall game logic in a Pygame-based game.

Attributes:
    - pygame: Pygame library for game development.
    - sys: System-specific parameters and functions.
    - settings: Game settings and configurations.
    - Level: Class managing individual game levels.
    - Overworld: Class managing the overworld and transitions between levels.
    - UI: Class handling user interface elements.

Classes:
    - Game: Manages the game loop, game status, UI, levels, and game attributes.

Methods:
    - __init__(self): Initializes the game attributes and necessary instances for the game.
    - create_level(self, current_level): Creates a new level instance based on the current level.
    - create_overworld(self, current_level, new_max_level): Creates a new overworld instance based on the current and maximum levels.
    - change_coins(self, amount): Updates the coins count based on the given amount.
    - change_health(self, amount): Updates the current health based on the given amount.
    - check_game_over(self): Checks if the game is over based on the player's health status.
    - run(self): Runs the game loop, updating the overworld or level based on the game status.

Usage:
    To use this module, create an instance of the Game class and run the game loop by calling the `run()` method. The game loop continuously checks for events, updates the game state, and manages transitions between levels and the overworld.
"""

class Game:
    def __init__(self):
        # setup the game arrtibutes
        self.max_level = 0 # the maximum level
        self.max_health = 100 # the maximum health
        self.current_health = 100 # the current health 
        self.coins = 0 # the amount of coins
        
        self.overworld = Overworld(0, self.max_level, screen,self.create_level) # create an instance of the overworld class
        self.status = 'overworld' # the status of the game
        
        # setup the ui
        self.ui = UI(screen)
    
    def create_level(self,current_level):
        self.level = Level(current_level, screen,self.create_overworld,self.change_coins,self.change_health) # create an instance of the level class
        self.status = 'level' # change the status of the game to level
        
    def create_overworld(self,current_level,new_max_level):
        if new_max_level > self.max_level:
            self.max_level = new_max_level
        
        self.overworld = Overworld(current_level, self.max_level, screen, self.create_level)
        self.status = 'overworld'
        
    def change_coins(self,amount):
        self.coins += amount
    
    def change_health(self,amount):
        self.current_health += amount
    
    def check_game_over(self):
        if self.current_health <= 0:
            self.current_health = 100
            self.coins = 0
            self.max_level = 0
            self.overworld = Overworld(0, self.max_level, screen,self.create_level)
            self.status = 'overworld'
        
    def run(self):
        if self.status == 'overworld':
            self.overworld.run() # run the overworld
        else:
            self.level.run() # run the level
            self.ui.show_health(self.current_health,self.max_health)
            self.ui.show_coins(self.coins)
            self.check_game_over()
            
# setup pygame and window
pygame.init()
screen = pygame.display.set_mode((screen_width, screen_height))
clock = pygame.time.Clock()
game = Game()

while True:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()

    screen.fill(('light blue'))
    game.run()

    pygame.display.update()
    clock.tick(60)
