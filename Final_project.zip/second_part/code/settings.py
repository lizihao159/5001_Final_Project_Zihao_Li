# Define the number of vertical tiles for the game screen.
# This determines the number of tiles arranged vertically.
# Adjust this value to change the vertical size of the game screen.
vertical_tile_number = 11

# Define the size of each tile (both width and height) in pixels.
# This value sets the dimensions for each tile used in the game.
tile_size = 64

# Calculate the total height of the game screen based on the number of vertical tiles and tile size.
# This value determines the overall vertical dimension of the game window.
screen_height = vertical_tile_number * tile_size

# Set the width of the game screen to a fixed value of 1200 pixels.
# Adjust this value to change the horizontal size of the game screen.
screen_width = 1200
