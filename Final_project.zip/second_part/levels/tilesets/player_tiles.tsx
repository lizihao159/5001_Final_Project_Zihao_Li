<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="setup_tiles" tilewidth="64" tileheight="64" tilecount="2" columns="2">
 <image source="../../graphics/setup_tiles.png" width="128" height="64"/>
</tileset>
